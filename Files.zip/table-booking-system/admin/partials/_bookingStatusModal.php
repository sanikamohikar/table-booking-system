<?php 
include 'connection.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {
if(isset($_POST['removeBooking'])) {
        $bookId = $_POST["bookId"];
        
        $sql = "DELETE FROM `tbl_booking` WHERE `booking_id`='$bookId'"; 
        $sql2 = "DELETE FROM `tbl_booking_status` WHERE `booking_id`='$bookId'";  
        $result = mysqli_query($conn, $sql);
        $result2 = mysqli_query($conn, $sql2);
        if ($result && $result2){
            
            echo "<script>alert('Removed.');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('Failed.');
                window.location=document.referrer;
                </script>";
        }
    }
}    
?>

<!-- Modal -->
<div class="modal fade" id="bookingStatus" tabindex="-1" role="dialog" aria-labelledby="bookingStatus" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: rgb(111 202 203);">
        <h5 class="modal-title" id="bookingStatus">Booking Status </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php
        $book_status_Sql = "SELECT * FROM `tbl_booking_status` where booking_id='$bookingid'";
        $bookstatusResult = mysqli_query($conn, $book_status_Sql);
        $bookstatusRow = mysqli_fetch_assoc($bookstatusResult);
        ?>
        <form action="partials/_bookingManage.php" method="post" >
                <div class="text-left my-2">    
                <b><label for="name">Booking Status:</label></b>
                <div class="row mx-2">
                    <select class="form-control col-md-12" id="bookStatus" name="status" required>
                    <option value="">Select Status</option>
                    <?php
                     if($bookstatusRow['booking_status']==1){ 
                    ?>
                    <option value="1" selected>Booking Confirmed</option>
                    <option value="2">Booking Cancelled</option>
                    <option value="3"> Waiting Time</option>
                    
                <?php }
                else if($bookstatusRow['booking_status']==2){ ?>
                    <option value="1">Booking Confirmed</option>
                    <option value="2" selected>Booking Cancelled</option>
                    <option value="3"> Waiting Time</option>
                    
              <?php  } else {?>
                <option value="1">Booking Confirmed</option>
                <option value="2">Booking Cancelled</option>
                <option value="3"> Waiting Time</option>
                
                <?php } ?>
                </select>
                </div>
            </div>
           <div class="text-left my-2" id="tableNo">    
    <b><label for="name">Table Number:</label></b>
    <div class="row mx-2"> 
        <select class="form-control col-md-12" id="tableValue" name="table_no" required>
            <option value="">Select Table Number</option>
            <?php 
            $tableSql = "SELECT * FROM `tbl_booking` WHERE booking_id ";
            $tableResult = mysqli_query($conn, $tableSql);
            while($tableRow = mysqli_fetch_assoc($tableResult)){
                echo "<option value='" . $tableRow['booking_id'] . "'>" . $tableRow['booking_id'] . "</option>";
            }
            ?>
        </select>
    </div>
</div>
<!-- <div class="text-left my-2" id="waitingTime" style="display: none;">    
    <b><label for="name">Waiting Time (in minutes):</label></b>
    <div class="row mx-2"> 
        <input type="time"  class="form-control col-md-12" id="waitingTimeInput" name="waiting_time">
    </div>
</div> -->


<!-- <div class="container" id="waitingTime" style="display: none;">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="countdownTime">Waiting Time:</label>
                <input type="number" class="form-control" id="countdownTime" name="waiting_time" placeholder="Enter Waiting time">
            </div>
            <div class="form-group">
                <label for="countdownTimer">Countdown Timer:</label>
                <input type="text" class="form-control" name="countdown" id="countdownTimer" placeholder="Countdown Timer" style="width: 200px; text-align: right;" disabled>
            </div>
        </div>
    </div>
</div> -->

     
<div class="text-left my-2 " id="waitingTime" >           
                 
                        <label for="countdownTime">Waiting Time (minutes):</label>
                        <div class="row mx-2">
                        <input type="number" class="form-control" id="countdownTime" name="countdown" placeholder="Enter Waiting time in minutes">
                    
                        <label for="countdownTimer">Countdown Timer:</label>
                        <input type="text" class="form-control"  id="countdownTimer" name="count_down" placeholder="Countdown Timer" style="width: 200px; text-align: right;" disabled>
                   
                    <button type="button" id="startCountdown" class="btn btn-primary">Start</button>
                    <button type="button" id="stopCountdown" class="btn btn-danger" style="display: none;">Stop</button>
   
                        </div>   
</div>         <!-- <div class="text-left my-2" id="tableNo">    
    <b><label for="name">Table Number:</label></b>
    <div class="row mx-2">
        <textarea id="tableInput" name="table_no" class="form-control col-md-12" placeholder="Enter Table Number" required></textarea>
    </div>
</div> -->

            <div class="text-left my-2">    
                <b><label for="name">Remarks:</label></b>
                <div class="row mx-2">
                <textarea class="form-control col-md-12" id="remarks" name="remarks" required ></textarea> </div>
            </div>
            </div>
            <input type="hidden" id="bookId" name="bookId" value="<?php echo $bookingid; ?>">
            <button type="submit" class="btn btn-success mb-2" name="updateStatus">Update</button>
        </form>
        </div>
    </div>
  </div>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
    $(function () {
        $('[data-toggle="popover"]').popover();
    });
</script>

<script type="text/javascript">
    $('#tableNo').hide();
    $('#waitingTime').hide();
    $(document).ready(function(){
    $('#bookStatus').change(function(){
   if($('#bookStatus').val()==1)
  {
     $('#tableNo').show();
     $('#tableValue').prop('required',true);
     $('#waitingTime').hide();
  }
  else if ($('#bookStatus').val() == 2) {
                $('#tableNo').hide();
                $('#tableValue').val('');
                $('#tableValue').removeAttr('required', false);
                $('#waitingTime').hide(); // Hide waiting time input if booking is canceled without waiting time
            } else if ($('#bookStatus').val() == 3) {
                $('#tableNo').hide();
                $('#tableValue').val('');
                $('#tableValue').removeAttr('required', false);
                $('#waitingTime').show(); // Show waiting time input if booking is canceled with waiting time
            } else {
                $('#tableNo').hide();
                $('#tableValue').val('');
                $('#tableValue').removeAttr('required', false);
                $('#waitingTime').hide(); // Hide waiting time input for other cases
            }
})
})
</script>
<!-- <script>
  document.getElementById('countdownTime').addEventListener('input', function() {
    var countdownTime = parseInt(this.value);
    if (!isNaN(countdownTime)) {
      var countdownDate = new Date();
      countdownDate.setMinutes(countdownDate.getMinutes() + countdownTime);
      var countdownTimer = setInterval(function() {
        var now = new Date().getTime();
        var distance = countdownDate - now;
        var minutes = Math.floor(distance / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Add leading zeros to minutes and seconds if they are less than 10
        minutes = (minutes < 10 ? '0' : '') + minutes;
        seconds = (seconds < 10 ? '0' : '') + seconds;

        document.getElementById('countdownTimer').value = minutes + 'm ' + seconds + 's';
        if (distance < 0) {
          clearInterval(countdownTimer);
          document.getElementById('countdownTimer').value = 'EXPIRED';
        }
      }, 1000);
    } else {
      document.getElementById('countdownTimer').value = '';
    }
  });
</script> -->
<script>
    $(document).ready(function(){
        var countdownInterval; // Variable to hold countdown interval

        // Function to start countdown
        $('#startCountdown').click(function(){
            var countdownTime = $('#countdownTime').val() * 60; // Convert minutes to seconds
            $('#countdownTimer').val(formatTime(countdownTime)); // Set initial value

            // Start countdown interval
            countdownInterval = setInterval(function(){
                countdownTime--;
                $('#countdownTimer').val(formatTime(countdownTime)); // Update countdown timer value

                // Send countdown value to backend via AJAX
                $.post('store_countdown.php', { countdown: countdownTime }, function(response){
                    // Response handling if needed
                    console.log(response);
                });

                // Stop countdown if countdownTime reaches 0
                if (countdownTime <= 0) {
                    clearInterval(countdownInterval);
                }
            }, 1000);

            // Toggle buttons
            $('#startCountdown').hide();
            $('#stopCountdown').show();
        });

        // Function to stop countdown
        $('#stopCountdown').click(function(){
            clearInterval(countdownInterval); // Stop countdown interval
            $('#startCountdown').show(); // Show start button
            $('#stopCountdown').hide(); // Hide stop button
        });

        // Function to format time (hh:mm:ss)
        function formatTime(seconds) {
            var hours = Math.floor(seconds / 3600);
            var minutes = Math.floor((seconds % 3600) / 60);
            var remainingSeconds = seconds % 60;

            // Add leading zeros if necessary
            hours = (hours < 10) ? "0" + hours : hours;
            minutes = (minutes < 10) ? "0" + minutes : minutes;
            remainingSeconds = (remainingSeconds < 10) ? "0" + remainingSeconds : remainingSeconds;

            return hours + ":" + minutes + ":" + remainingSeconds;

        }
    });
    </script>