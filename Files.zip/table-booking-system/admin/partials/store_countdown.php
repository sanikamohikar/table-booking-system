<?php
// Assuming you have already established a database connection
include 'connection.php';
// Check if countdown value is received via POST
if(isset($_POST['countdown'])) {
    // Get the countdown value
    $countdown = $_POST['countdown'];

    // Insert countdown value into the database table
    $sql = "INSERT INTO waiting_time (countdown_value) VALUES (:countdown)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['countdown' => $countdown]);

    // Optionally, you can send a response back to the frontend if needed
    echo "Countdown value stored successfully.";
} else {
    // Handle case when countdown value is not received
    echo "Countdown value not received.";
}
?>
